﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Linq;

namespace LinqDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("LINQ implementation in C#");
            //Definin Score query
            int[] scores = new int[] { 98, 65, 80, 15, 39, 55, 72 };
            // String
            string[] cities = new string[] { "Banglore", "Hyderbad", "Delhi", "Pune" };


            IEnumerable<int> Scorequery =
                from score in scores
                where score > 40
                orderby score ascending
                select score;
            //Executing query 

            Console.WriteLine("Values Greater than 40 in ascending order");
            foreach (var item in Scorequery)
            {

                Console.WriteLine(item + " ");
            }

            IEnumerable<string> cityquery =
                from city in cities
                where city is "Bangalore" or "Hyderabad" or "Delhi"
                select city;

            Console.WriteLine("City is");
            foreach (var item2 in cityquery)
            {
                Console.WriteLine(item2 );
            }
        }
    }
}