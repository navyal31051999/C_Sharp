﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multi_Threading
{
    class Threading
    {

        public void Display()
        {
            Console.WriteLine("Implementing Thread 1");
            for(int i=0;i<100;i++)
            {
                Console.WriteLine("\n" + i);
            }

            Console.WriteLine("Thread 1 Ends");
        }

    }
}
