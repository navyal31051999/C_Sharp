﻿using System;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;
using System.Text;
namespace Multi_Threading
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Implementing MultiThreading!");
            Threading t = new Threading();
            Console.WriteLine("Main Thread Started");
            t.Display();

            //Create ref of thread 
            ThreadStart th1 = t.Display;
            Thread thread1 = new Thread(th1);
            thread1.Start();
            Thread thread2 = new Thread(th1);
            thread2.Start();
 
            Console.WriteLine("Main Thread ends");
            Console.ReadKey();

        }
    }
}
