﻿using System;
using System.Reflection;

namespace Reflection
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Reflection in C#....");
            Type T = typeof(int);
            Console.WriteLine("Type Of Name : {0}",T.Name);
            Console.WriteLine("Full name of the type defined : {0}", T.FullName);
            Console.WriteLine("Type Of Assembly : {0} ",T.Assembly);
            Console.WriteLine("Information about base type : {0}", T.BaseType);
            Console.WriteLine(T.MetadataToken);

            Console.WriteLine("For Type Boolean");
            Type T1 = typeof(Boolean);
            Console.WriteLine("Type Of Name : {0}", T1.Name);
            Console.WriteLine("Full name of the type defined : {0}", T1.FullName);
            Console.WriteLine("Type Of Assembly : {0} ", T1.Assembly);
            Console.WriteLine("Information about base type : {0}", T1.BaseType);
            Console.WriteLine(T1.MetadataToken);
        }
    }
}
