﻿using System;

namespace Dynamic_Object
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Dynamic Object!");
            Dynamic d1 = new Dynamic();
            d1.First_Method();
            d1.Second_Method();

            Console.WriteLine("Dynamic call ");
            dynamic d2 = new Dynamic();
            d2.First_Method();
            d2.Second_Method();
        }
    }
}
