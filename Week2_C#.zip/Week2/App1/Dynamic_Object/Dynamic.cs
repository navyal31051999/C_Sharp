﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dynamic_Object
{
    class Dynamic
    {
        public Dynamic() { }
        public Dynamic(int v) { }

        public void First_Method() {
            Console.WriteLine("Inside First Method");
        }

        public void Second_Method() {
            Console.WriteLine("Inside Second Method");
        }
    }
}
