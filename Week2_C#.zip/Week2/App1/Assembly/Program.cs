﻿using System;
using System.Reflection;


namespace Assembly
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(" Implementing Assemblies in C#!");
            Stringer myStringInstance = new Stringer();
            Console.WriteLine("Client code executes");
            myStringInstance.stringermethod();
        }
    }
}
