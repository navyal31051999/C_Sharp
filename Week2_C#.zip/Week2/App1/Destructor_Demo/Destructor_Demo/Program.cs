﻿using System;

namespace Destructor_Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(" Finalizer!");
            Class1 obj = new Class1("Helloo ");
            obj.Display_Msg();
            obj.Dispose();
        }
    }
}
