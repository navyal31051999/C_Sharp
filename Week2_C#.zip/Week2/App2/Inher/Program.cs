﻿using System;

namespace Inher
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                throw new StudentNotFoundException("Student not found", "John");
                }
            catch(StudentNotFoundException s)
            {
                Console.WriteLine("Student exception not caught\n" + s.Message);
            }

        }
    }
}
