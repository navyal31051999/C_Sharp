﻿using System;

namespace File_Handling
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("-----Implementing Different Types of Inheritence ----");
           //Creating object of child Class
            ChildClass obj1 = new ChildClass();
            //Calling function of Base Class
            obj1.Display();
            //Calling object of child class
            obj1.Child_Display();
        }
    }
}
