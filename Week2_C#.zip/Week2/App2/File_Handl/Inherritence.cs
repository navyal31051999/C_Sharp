﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace File_Handl
{
    class Inherritence
    {
        public void Display()
        {
            Console.WriteLine("base Class Function is invoked")
        }
    }
    class ChildClass : Inherritence
    {
        public void Child_Display()
        {
            base.Display();
            Console.WriteLine("Child Class Display() is invoked!!")
    }

    }

}

}
