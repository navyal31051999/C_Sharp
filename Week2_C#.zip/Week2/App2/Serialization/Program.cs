﻿using System;
using System.Text.Json;

namespace Serialization
{
    public class WeatherForecast
    {
        public DateTimeOffset Date { get; set; }
        public int TemperatureCelsius { get; set; }
        public string Summary { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
           
            var weatherForecast = new WeatherForecast
            {
                Date = DateTime.Parse("2021-10-13"),
                TemperatureCelsius = 26,
                Summary = "Cloudy"
            };

            string jsonString = JsonSerializer.Serialize(weatherForecast);

            Console.WriteLine("Details OF Bangalore Weather {0} ",jsonString);
        }
    }
}
