﻿using System;
using System.IO;

namespace File_Conn
{
    class Program
    {
        static void Main(string[] args)
        {

                FileStream fs = new FileStream("D:\\New folder\\Docs.txt", FileMode.OpenOrCreate);
                StreamReader sr = new StreamReader(fs);
                Console.WriteLine("File Handling");
                string str = sr.ReadLine();
                while (str != null)
                {
                    Console.WriteLine(str);
                    str = sr.ReadLine();
                }

            fs.Flush();
            fs.Close();


            FileStream write = new FileStream("D:\\New folder\\Docs.txt", FileMode.Append);
            StreamWriter s = new StreamWriter(write);
            Console.WriteLine("Enter the  Content into The file");
            string content = Console.ReadLine();
            s.WriteLine(content);
            s.Flush();
            write.Flush();
            write.Close();

        }

    }
    }