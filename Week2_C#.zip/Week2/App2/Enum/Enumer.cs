﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enum
{
  
      
    class Enumer
    {

    }
    public enum Myenum
    {
        red = 1,
        blue = 7,
        green = 4
    }

}
