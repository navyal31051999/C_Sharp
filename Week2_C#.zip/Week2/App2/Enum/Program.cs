﻿using System;
using static Enum.Enumer;

namespace Enum
{
    class Program
    {
        
        static void Main(string[] args)
        {


            Console.WriteLine(Myenum.red);
        }

    }
    
}
