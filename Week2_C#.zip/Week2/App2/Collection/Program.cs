﻿using System;
using System.Collections.Generic;
namespace Collection
{
    class Program
    {
        static void Main(string[] args)
        {
            var Mylist = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9 };


            //foreach (var item in Mylist)
            var Mycars = new List<string> { "tesla", "bmw", "porsche"};
             for(int i=0;i<Mycars.Count;i++ )
            {
                Console.WriteLine(Mycars[i]);
            }

        }
    }
}
